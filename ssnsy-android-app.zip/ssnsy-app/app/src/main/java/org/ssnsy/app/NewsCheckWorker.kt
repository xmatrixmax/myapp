package org.ssnsy.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.PendingIntent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

/**
 * Polls the site's WordPress REST API for the latest published post and
 * fires a local notification the first time a new post id shows up.
 *
 * Note: this app has no backend of its own, so "new post" detection only
 * happens whenever this worker runs (about once an hour, subject to
 * Android's Doze/battery restrictions). For true real-time push the moment
 * an article goes live, a small server (or Firebase Cloud Messaging with a
 * Cloud Function that watches the WP REST API) would need to trigger the
 * push instead of the device polling for it.
 */
class NewsCheckWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    private val prefs by lazy {
        applicationContext.getSharedPreferences("ssnsy_prefs", Context.MODE_PRIVATE)
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient()
            val request = Request.Builder()
                .url("https://www.ssnsy.org/wp-json/wp/v2/posts?per_page=1&_fields=id,link,title")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext Result.retry()
                val body = response.body?.string() ?: return@withContext Result.retry()
                val arr = JSONArray(body)
                if (arr.length() == 0) return@withContext Result.success()

                val post = arr.getJSONObject(0)
                val id = post.getInt("id")
                val link = post.getString("link")
                val rawTitle = post.getJSONObject("title").getString("rendered")
                val title = rawTitle.replace(Regex("<[^>]*>"), "").trim()

                val lastSeenId = prefs.getInt("last_post_id", -1)

                if (lastSeenId == -1) {
                    // First run: just record the baseline, don't notify.
                    prefs.edit().putInt("last_post_id", id).apply()
                } else if (id != lastSeenId) {
                    prefs.edit().putInt("last_post_id", id).apply()
                    showNotification(title, link)
                }
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun showNotification(title: String, link: String) {
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_URL, link)
        }
        val pendingIntent = PendingIntent.getActivity(
            applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(applicationContext, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(applicationContext.getString(R.string.app_name))
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(title))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            applicationContext.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        ) {
            NotificationManagerCompat.from(applicationContext).notify(1001, notification)
        }
    }
}
